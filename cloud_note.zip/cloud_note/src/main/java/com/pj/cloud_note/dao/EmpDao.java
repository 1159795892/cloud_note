package com.pj.cloud_note.dao;

import com.pj.cloud_note.entity.Emp;

public interface EmpDao {
	public void save(Emp emp);
}
